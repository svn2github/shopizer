(function($){
	
	var methods = {
		
		init: function( options ) {
			return this.each(function(){
				var $this = $(this);
				//setup our data object
				//default settings
				$this.data('rpdialog', $.extend({
					'overlayOpacity'	: '0.6',
					'overlayColor'		:'#000',
					'borderColor'		: '#3939cc',
					'borderOpacity'		: '0.6',
					'borderWidth'		: '10px',
					'overflow'			: 'auto',
					'onclose'			: function(){}
				}, options));
				var rpdialog = $this.data('rpdialog');
				//create global the overlay
				rpdialog.overlay = $('<div />').addClass('rpdialog_overlay')
					.css({
						'top'				: 0,
						'left'				: 0,
						'position'			: 'absolute',
						'opacity'			: rpdialog.overlayOpacity,
						'background-color'	: rpdialog.overlayColor,
						'display'			: 'none'
					}).appendTo('body').on('click.rpdialog', function(){
						methods.close.apply($this);
					});
				//create dialog container
				rpdialog.dialog = $('<div />')
					.addClass('rpdialog')
					.append($('<div/>').addClass('rpdialog_border').css({
						'position'	: 'absolute',
						'top'		: 0,
						'bottom'	: (document.documentMode === 7 ? '-' + rpdialog.borderWidth : 0),
						'left'		: 0,
						'width'		: '100%',
						'background': rpdialog.borderColor,
						'opacity'	: rpdialog.borderOpacity,
						'-moz-opacity' : rpdialog.borderOpacity,
						'filter'	: 'alpha(opacity=' + (parseFloat(rpdialog.borderOpacity)*100) + ')'
					})) //border
					.append($this.css({
						'position'	: 'relative',
						'margin'	: rpdialog.borderWidth,
						'top'		: (document.documentMode === 7 ? rpdialog.borderWidth : 0),
						'overflow'	: rpdialog.overflow
					})) //content
					.css({
						'position'	: 'fixed',
						'display'  	: 'none'
					})
					.appendTo('body');
				
				//hook events
				$this.find('.close').attr('title', 'Close').click(function(e){
					$this.rpdialog('close');
				});
				
				$(window).on('resize.rpdialog', function(){
					methods.resize.apply($this);
				});
				$(document).on('resize.rpdialog', function(){
					methods.reisze.apply($this);
				});
				$(document).on('keyup.rpdialog', function(key){
					if (key.which == 27) {
						key.preventDefault();
						methods.close.apply($this);
					}
				});
			});
		},
		open: function( param ) {
			return this.each(function(){
				var $this = $(this);
				var rpdialog = $this.data('rpdialog');
				rpdialog.overlay.css('z-index', methods.topmost() + 1).show('fade', 'fast');
				rpdialog.dialog.css('z-index', methods.topmost() + 1).fadeIn(function(){
					if (typeof param === 'function')
						param();
				});
				methods.resize.apply($this);
			});
		},
		close: function( param ) {
			return this.each(function(){
				var $this = $(this);
				var rpdialog = $this.data('rpdialog');
				rpdialog.overlay.hide();
				rpdialog.dialog.fadeOut(function(){
					rpdialog.dialog.css('z-index', 0);
					rpdialog.overlay.css('z-index', 0);
					rpdialog.onclose();
					if (typeof param === 'function')
						param();
				});
			});
		},
		topmost: function() {
			var zmax = 0;
			$('.rpdialog_overlay, .rpdialog').each(function(){
				var c = parseInt($(this).css('z-index'));
				zmax = c > zmax ? c : zmax;
			});
			return zmax;
		},
		resize: function() {
			var $this = $(this);
			var rpdialog = $this.data('rpdialog');
			var h = $(document).height();
			var w = $(window).width();
			rpdialog.overlay.css({'width':w, 'height':h});
			
			//if the dialog is bigger than the viewport or from a mobile device make it scrollable
			var isConstrained = ($this.width() > $(window).width() || $this.height() > $(window).height() || $.browser.mobile);

			var ww = $(window).width();
			var wh = $(window).height();
			rpdialog.dialog.css({
				'top': wh/2 - ($this.height()/2) - 28,
				'left': ww/2 - ($this.width()/2) - 28,
				'position' : isConstrained ? 'absolute' : 'fixed'
			});
			
			if (isConstrained && $this.is(':visible')) {
				$('html, body').animate({scrollTop: $this.offset().top}, 1000);
			}
			
		}
			
	};
	
	$.fn.rpdialog = function( param ) {

		if (methods[param]) {
			return methods[param].apply(this, Array.prototype.slice.call(arguments, 1));
		}
		else if (typeof param === 'object' || !param) {
			return methods.init.apply(this, arguments);
		}
		else {
			$.error('IllegalArgumentException: ' + param);
		}
		
	};
	
})(jQuery);