/*
 * Displays a small drop notification at the top of the page
 * jQuery required
 */
(function($){
	$('div#error').click(function(e){
		e.preventDefault();
		$(this).find('.message').each(function(){
			$(this).fadeOut(function(){
				$(this).remove();
			});
		});
	});
	
	$.fn.flash = {
		
		status : function(message) {
			var $flash = $('#flash');
			if (message === 'hide') {
				$flash.hide();
				return this;
			}
			
			$('div#error').css('opacity', 0.2);
			$('#flash #message').stop().css('opacity', 1).html('<span class="message_icon loading_icon"></span>' + message);
			if (!$flash.is(':visible'))
				$flash.effect('slide',{direction:'up'});
			return this;
		},
			
		notice : function(message, timeout) {
			var $flash = $('#flash');
			clearTimeout($flash.data('flash.timeout'));
			if (message === 'hide') {
				$flash.fadeOut('fast');
				return this;
			}
			$('div#error').css('opacity', 0.2);
			if (timeout == undefined) timeout = 5000;
			$flash.data('flash.timeout', setTimeout(function(){
				$flash.fadeOut('slow', function(){
					$('#flash #message').html('');
					$('div#error').css('opacity', 1);
					$flash.data('flash.timeout', 0);
				});
			}, timeout));
			$('#flash #message').stop().css('opacity', 1).html('<span class="message_icon green_icon"></span>' + message);
			if (!$flash.is(':visible'))
				$flash.effect('slide',{direction:'up'});
			return this;
		},
		
		error : function(message) {
			if (message === 'hide') {
				$('div#error').hide().find('.message').remove();
				return this;
			}
			var $message = $('div#error .message');
			if ($message.length == 0) {
				$('div#error').append($('<div/>')
						.addClass('message')
						.css('background-color', 'red')
						.html('<a href="#" class="xbutton" title="Close"></a><span class="message_icon red_icon"></span>' + message + '<br/>'));
			}
			else {
				$message.html($message.html() + message + '<br/>');
			}
			$('div#error').fadeTo('fast', 1);
			return this;
		}
	};
	
})(jQuery);