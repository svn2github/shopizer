(function($) {

	$.fn.amount = function(opts){

		var defaults = {
			prefix: '$',
			centsSeparator: '.',
			thousandsSeparator: ',',
			centsLimit: 2,
			allowNegative: true,
			triggerChange: false,
			allowDot: true
		};

		var options = $.extend(defaults, opts);

		return this.each(function(){

			// pre defined options
			var obj = $(this);

			// load the pluggings settings
			var prefix = options.prefix;
			var centsSeparator = options.centsSeparator;
			var thousandsSeparator = options.thousandsSeparator;
			var centsLimit = options.centsLimit;
			var allowNegative = options.allowNegative;

			// skip everything that isn't a number
			// and also skip the left zeroes
			function toNumbers(str) {
				var num = parseFloat(str.replace(/\D/g, ''));
				return isNaN(num) ? '' : num.toString();
			}

			// format to fill with zeros to complete cents chars
			function leadingZeroes(str) {
				while (str.length<(centsLimit+1)) str = '0'+str;
				return str;
			}

			// format as price
			function format(str) {
				// formatting settings
				var formatted;
				
				if (options.allowDot) {
					formatted = str.replace(/[\$,]/g,'');
					if (formatted == '.')
						formatted = '0' + formatted;
					
				}
				else {
				
					formatted = leadingZeroes(toNumbers(str));
					// split integer from cents
					var centsVal = formatted.substr(formatted.length-centsLimit,centsLimit);
					var integerVal = formatted.substr(0,formatted.length-centsLimit);
	
					// apply cents pontuation
					formatted = integerVal.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + thousandsSeparator + "")+centsSeparator+centsVal;
	
					// if the string contains a dash, it is negative - add it to the begining (except for zero)
					if (allowNegative && str.indexOf('-') != -1 && (integerVal != 0 || centsVal != 0)) formatted = '-' + formatted;
					
				}

				//Don't prepend $ on android devices, since it causes the cursor to jump to the wrong position and can lead to users entering wrong amount.
				//This appears to be a bug with mobile android, so in the meantime, fix issue this way until there is more time to fully track down this issue
				if(navigator.userAgent.toLowerCase().indexOf("android") == -1) {
					// apply the prefix
					if (prefix && formatted.length > 0) formatted = prefix+formatted;
				}
                
				return formatted;
			}
			

			function getSelected() {
				if (window.getSelection) {
					return window.getSelection();
				} else if (document.getSelection) {
					return document.getSelection();
				} else {
					var selection = document.selection
							&& document.selection.createRange();
					if (selection.text) {
						return selection.text;
					}
					return false;
				}
				return false;
			}


			// filter what user type (only numbers and functional keys)
			function keyDown(e) {

				var code = (e.keyCode ? e.keyCode : e.which);
				var functional = false;

				// allow key numbers, 0 to 9
				if((code >= 48 && code <= 57) || (code >= 96 && code <= 105)) {
					functional = true;
				}

				// check Backspace, Tab, Enter, Delete, and left/right arrows
				if (code ==  8) functional = true;
				if (code ==  9) functional = true;
				if (code == 13) functional = true;
				if (code == 46) functional = true;
				if (code == 37) functional = true;
				if (code == 39) functional = true;
				
				//if allow dot
				if (options.allowDot) {
					if (code == 190 || code == 110) {
						functional = (obj.val().indexOf('.') == -1 || new String(getSelected()).replace(/^\s+|\s+$/g,'').indexOf('.') != -1);
					}
				}
				
				if (e.altKey || e.ctrlKey || e.shiftKey || e.metaKey) functional = true;
				if (allowNegative && (code == 189 || code == 109)) functional = true; // dash as well

				if (!functional) {
					e.preventDefault();
					e.stopPropagation();
				}

			}

			// Add prefix on focus
			function addPrefix() {
				var val = obj.val();
				obj.val(prefix + val);
			}
            
			// Clear prefix on blur if is set to true
			function removePrefix() {
				if($.trim(prefix) != '') {
					var array = obj.val().split(prefix);
					obj.val(array[1]);
				}
			}
            
			// bind the actions
			obj.bind('keydown', keyDown);
			obj.bind('keyup', function(e) {
				var str = obj.val();
				if ($.trim(str) == '')
					return;
				var price = format(str);
				if (str != price) {
					obj.val(price);
				}
				var code = e.keyCode;
				
				var fireChange = (code >= 48 && code <= 57) || (code >= 96 && code <= 105);
				if (code ==  8) fireChange = true; //backspace
				if (code == 46) fireChange = true; //delete
				
				//ctrl + V
				if (obj.data('formatamount.lastkeycode') == 17 && code == 86) fireChange = true;
				obj.data('formatamount.lastkeycode', code);
				
				//should we trigger a change event
				if(options.triggerChange && fireChange) {
					obj.change();
				}
			});
			//only bind the blur if allowDot option is true because the value is already pre formatted otherwise
			if (options.allowDot) {
				obj.bind('blur', function() {
					var curVal = obj.val();
					var dotIndex = curVal.indexOf('.');
					var decimalVal = curVal.substr(dotIndex + 1);
					if (dotIndex != -1) {
						if (decimalVal.length < 2) {
							for (var j=0; j<2-decimalVal.length; ++j) {
								curVal += '0';
							}
							obj.val(curVal);
						}
					}
					else if (!isNaN(parseInt(curVal.replace('$','')))) {
						curVal += '.00';
						obj.val(curVal);
					}
				});
			}

			// If value has content
			if (obj.val().length>0){
				obj.trigger('keyup');
				if (options.allowDot == false)
					removePrefix();
			}

		});

	};
	
	/******************
	* returns the amount in cents
	*******************/
	jQuery.fn.toCents = function(){
		
		var field = $(this).val();
		var result = "";
		
		for(var f in field) {
			if(!isNaN(field[f]) || field[f] == "-") result += field[f];
		}
		
		return result;
	};

})(jQuery);