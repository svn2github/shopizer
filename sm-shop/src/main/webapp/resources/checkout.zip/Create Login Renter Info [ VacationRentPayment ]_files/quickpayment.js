//Javascript file for oneclickpayment_001.jsp

var requestUrl = '/rest/v1/oneClick/';

// For Reference
var account = {id:{}, display:{}, type:{}, process:{}, expired:{},
			uiNumber:{}, expMonth:0, expYear:0, first:{}, last:{},
			address:{}, city:{}, state:{}, zip:{}};

// Person's fees and accounts
var accounts = [{}];

// Selected Account is Expired
var selectedIsExpired = false;
var updateCCForm = false;

// Last selected Account
var lastSelectedDisplay = "";
var lastSelectedKey = "";
var lastSelectedType = "";

// init on page load. Start Preliminary Loads
$(function(){
	//reset the sensitive fields
	$('#ccnum, #routingNumber').val("").change();
	// init screen on initial load
	init();
});



/* init function to indicate where the main onload logic happens */
function init(){
	
	bindPaymentButtonOnline();
	
	$('#firstNameOnCard').focus(function(){
		if ($.trim($(this).val()) == '')
			$(this).val($('#firstname').val()).change().select();
	});
	
	$('#lastNameOnCard').focus(function(){
		if ($.trim($(this).val()) == '')
			$(this).val($('#lastname').val()).change().select();
	});
	
	$('#nameOnAccount').focus(function(){
		if ($.trim($(this).val()) == '')
			$(this).val($('#firstname').val() + ' ' + $('#lastname').val()).change().select();
	});
	
	calculateTotal();

	// actions that need to take place right before form submits
	$('#paymentForm').submit(function(e){
		var channel = $('input[name=selectedChannel]').val();
		if (channel == 'ONLINE') {
			$ ('input[name=IsTextButtonClicked]').val("false");
			$ ('input[name=IsEmailButtonClicked]').val("false");
		}
		else if (channel == 'EMAIL') {
			$ ('input[name=IsTextButtonClicked]').val("false");
			$ ('input[name=IsEmailButtonClicked]').val("true");
		}
		else if (channel == 'TEXT_MESSAGE') {
			$ ('input[name=IsTextButtonClicked]').val("true");
			$ ('input[name=IsEmailButtonClicked]').val("false");
		}

	});
}

// validates the mobile number if sendTxtReceipt or receiveTxtReminder is
// checked
function validateMobile(field, rules, i, options) {
	if ($.trim(field.val()) == '')
		return "* This field is required.";
};

function validateCVV(field, rules, i, options) {
	if (field.is(':visible') && $.trim(field.val()) == '') {
		return "* Please enter your CVV number.";
	}
}

function reveal(show) {
	// disable other form inputs
	$('#payment_summary input').attr('disabled', show);
	updateFutureAndPendingCharges();
	// fade out other form elements
	$('#renter_information, #payment_method, #payment_summary, #payment_summary, #posted_note').fadeTo('fast', show ? 0.3 : 1);
	// disable the complete payment button
	var $btn = $('#complete_payment_btn');
	$btn.attr('disabled', show);
	show ?	$btn.addClass('grey') : $btn.removeClass('grey');
}

/**
 * This is called from rp.js when the payment type is detected
 * @param type
 */
function updateServiceFee(data) {
	$('#serviceFeeType').val(data.type);
	calculateTotal();
}

function setupServiceFeeType(isEcheckTab) {
	isEcheckTab ? clearNewCCForm() : clearNewBankForm();
	updateServiceFee({type:serviceFeesByChannel[$('input[name=selectedChannel]').val()]['defaultPaymentTypeFees'][isEcheckTab ? 'BankAccount' : 'CreditCardAccount']});
}

function getInitialServiceFeeType() {
	var defaultCard = serviceFeesByChannel[$('input[name=selectedChannel]').val()]['defaultPaymentTypeFees']['CreditCardAccount'];
	var serviceType = $.trim($('#serviceFeeType').val());
	if (serviceType == '') {
		serviceType = defaultAddPaymentMethodToACH == 'true' ? 'eCheck' : defaultCard;
	}
	
	if (noCCPermitted)
		return 'eCheck';
	if (noBankPermitted)
		return defaultCard;
	
	return serviceType;
}

/********************************************************************************************************* */
// Moved from rp.js
/********************************************************************************************************* */
$(function(){

	var $confirm = $('#confirmDialog');
	var $accountTabs = $('#account_type_tabs');
	
	$confirm.dialog({
		autoOpen: false,
		resizable: false,
		modal: true,
		buttons: {
			'Continue' : function() {
				$accountTabs.tabs('select', $(this).data('ui').index);
				$(this).dialog('close');
			},
			'Cancel' : function() {
				$(this).dialog('close');
			}
		}
	});
	
	// quickpayment add account tabs
	$accountTabs.tabs({
		create: function(e,ui) { 
			var serviceType = getInitialServiceFeeType();
			setAllowedAddPaymentTypes('#account_type_tabs', 1, 0, false, noCCPermitted, noBankPermitted, populateCCTabs, serviceType !== '' ? (serviceType == 'eCheck' ? 'true' : 'false') : defaultAddPaymentMethodToACH);
			if (serviceType === '')
				setupServiceFeeType(serviceType == 'eCheck');
			else 
				updateServiceFee({type:serviceType});
			//late binding so the confirmation dialog won't popup on load since setAllowedAddPaymentTypes selects the tab programatically
			$(this).tabs({
				select : function(e, ui) { 
					$('form').validationEngine('hideAll');
					if (!$confirm.dialog('isOpen') && (!isNewBankDataEmpty() || !isNewCCDataEmpty())) {
						$confirm.data('ui', ui).dialog('open');
						return false;
					}
					setupServiceFeeType(ui.panel.id != 'cc_tab');
				}
			});	
		},
		show : function(e, ui) {
			//always show billing address fields for vacation
			$('#billing_summary').hide();
			$('#billing_address #billing_form').show();
		},
		fx:{height: "toggle", opacity: 'toggle', duration: 300 }
	});

	//Throw error if person is restricted from paying with all possible methods.
	if (!permits) {
		$.fn.flash.error('hide').error("Payments are not currently accepted for your profile. Please contact your manager for further information."); //E477
	}

});



/** ****************************************************************************************************** */
// Payment Method
/** ****************************************************************************************************** */
// Add New Account
$(function(){		
	
	//refresh skinned select dropdown
	$('#exp_month').trigger('customOnChange.refresh');
	$('#exp_year').trigger('customOnChange.refresh');

});

function clearNewBankForm(){
	$('input[name="nameOnAccount"]').val("").change();
	$('input[name="routingNumber"]').val("").change();
	$('input[name="accountNumber"]').val("").change();
}


function clearNewCCForm(){
	$('input[name="ccnum"]').val("").change();
	$('input[name="firstNameOnCard"]').val("").change();
	$('input[name="lastNameOnCard"]').val("").change();
	$('#exp_month').val('').trigger('customOnChange.refresh');
	$('#exp_year').val('').trigger('customOnChange.refresh');
	$('#addCardLogo').data('oldValue', '').empty();
}

/** ****************************************************************************************************** */
// Payment Summary
/** ****************************************************************************************************** */

// Show/Hide service fee line item
function handleServiceFeeLineItem(totalServiceFee){
	if (totalServiceFee == 0){
		$('#service_fee_line_item').hide();
		$('#isServiceFee').hide();
	} else {
		$('#service_fee_line_item').fadeIn('slow');
		$('#isServiceFee').fadeIn('slow');
	}
}

/** ****************************************************************************************************** */
// Line Items
/** ****************************************************************************************************** */

$(function() {	
	// Handle change in line item totals
	var lineItems = $('[id^="lineItem_"]').toArray();
	$.each(lineItems, function(index, lineItem){		
		$(lineItem).change(function(e){
			restrictAmountTwoDecimal(this);
			calculateTotal();
		});
	});
	
});

// Calculate integrated line items
function calculatePreTotal(){
	if (integrated == "true"){
		var currencySymbol = "$";
		var total = 0;
		
		if (totalCurrentCharges) {
			var neg = false;
			var totalCur = totalCurrentCharges.replace(',','');
			if (totalCur.substr(0,1) == '-'){
				neg = true;				
				totalCur = totalCur.substr(1);
			}
			currencySymbol = totalCur.substr(0,1);
			if (neg == true) {
				total -= parseFloat(totalCur.substr(1));
			} else {
				total += parseFloat(totalCur.substr(1));
			}
			
		}
		
		// Optional Fees (Checkboxes)
		var optFees = $('[id^="optional_amount"]').toArray();
		$.each(optFees, function(index, optFee){
			var inputId = ($(optFee).attr("id")).replace("amount","input");
			var value = $(optFee).text().replace(',','');
			var negative = false;
			if (value.charAt(0) == "-"){
				negative = true;
				value = value.substr(1);
			}
			checkCurrency(currencySymbol, value.substr(0,1));
			if ($('#'+ inputId).attr('checked')){	
				if (negative == true) {
					total -= parseFloat(value.substr(1));
				} else {
					total += parseFloat(value.substr(1));
				}
			} 
	
		});
		
		// SetTotalPrePayment
		var totalStr;
		if (total < 0) {
			totalStr = "-" + currencySymbol + Math.abs(total).toFixed(2);
			$("#integrated_total").html(totalStr);
			if(prepopulateLineItem == "true") {
				total = 0;
				var paymentStr = currencySymbol + total.toFixed(2);
				$("#lineItem_0").val(paymentStr);
				calculateTotal();
			}
		} else {
			totalStr = currencySymbol + total.toFixed(2);
			$("#integrated_total").html(totalStr);
			if(prepopulateLineItem == "true"){
				$("#lineItem_0").val(totalStr);
				calculateTotal();
			}
		}
		
	}	
};

//Calculates line items
function calculateTotal(){
	var currencySymbol = "$";
	var total = 0;	

	// Line Items
	var lineItems = $('[id^="lineItem_"]').toArray();
	var count = 0;
	$.each(lineItems, function(index, lineItem) {		
		var inputAmount = $(lineItem).val();
		if(inputAmount) {
			var amount = checkValidCurrencyInput(inputAmount);
			if (amount == "invalid" || amount == 0){
				$(lineItem).val('');//.blur();			
			} else {
				total += amount;
			}
		}
		count++;
	});
	$('input[name="property_total"]').val(currencySymbol + total.toFixed(2));
	
	//do subtotal -- before service fee and coupon -- toFixed(2) not really needed anymore since restrictAmountTwoDecimal takes care of it
	$('input[name=subTotal]').val(total);
	
	// Service Fees
	calculateServiceFee(total);	
};

function finalizeTotal(totalToProperty, totalServiceFee) {
	var currencySymbol = "$";
	var total = totalToProperty + totalServiceFee;
	
	var totalFeeStr = currencySymbol + totalServiceFee.toFixed(2);
	var origFee =$('input[name="serviceFeeAmount"]').val();
	$('input[name="serviceFeeAmount"]').val(totalFeeStr);
	handleServiceFeeLineItem(totalServiceFee);
	// Promotions
	
	var promoAmount = $('#promoValue').val();
	if(promoAmount) {
		var pamountStr = promoAmount.substr(2);
		var pamount = checkValidCurrencyInput(pamountStr);
		if (pamount == "invalid") { 
			$('#promoValue').val('');
			return;
		} else {
			total = total - pamount; 
		}
	}	
	
	// Set Total Payment
	var totalStr = currencySymbol + total.toFixed(2);
	$("#amount_total").val(totalStr);
	
	// Check promotion value if service fee changes
	if (origFee != totalFeeStr) {
		PromoCode.submitPromotionEntry();
	}
}


//Calculates service fee 
function calculateServiceFee(total) {

	// if RPNow, Set all fees to 0, special business rule for RPN
	if (isRPNow && lastSelectedType.toLowerCase() == "echeck") {		
		finalizeTotal(total, 0);
		return;
	}

	// get service fee locally using service fees by channel loaded on page load to avoid ajax call
	var serviceFee = getServiceFeesForAccount();
	// safety check. if service fees are invalid, code higher up chain will disable payment button and show error msg. let code proceed since finalizeTotal shows/hides display items 
	if(typeof(serviceFee) === 'undefined'){
		serviceFee = {residentFlatFee: 0, residentRate: 0, minimumFee: 0};
	}
	
	var totalServiceFee = calculateServiceFeeLocal(total, serviceFee.residentFlatFee, serviceFee.residentRate, serviceFee.minimumFee);
	finalizeTotal(total, totalServiceFee);			
}

//restrict to two decimal places
function restrictAmountTwoDecimal(input){
	var curVal = $(input).val();
	var dotIndex = curVal.indexOf('.');
	var decimalVal = curVal.substr(dotIndex + 1);
	if (dotIndex != -1) {
		if (decimalVal.length > 2) {
			$(input).val(curVal.slice(0, dotIndex) + "." + decimalVal.substr(0,2));
		}
	}
}

/* update ui and vars based on new supported channels */
function updateSupportedChannelsPaymentOptions(){

	var paymentHeading = '';

	// update accordingly
	if (isTextPaymentAllowedForAccount() && isEmailPaymentAllowedForAccount()){
		paymentHeading = ' Phone or Email';
		$('#mobile_number_box').fadeIn();
		$('#text_email_box').fadeIn();
		$('#text_mobile_box').fadeIn();
		$('#promo_line_item').hide();
		//enable rentbytxt checkbox
		$('input[name="receiveTxtReminder"]').attr('checked',true);
		setCheckBoxValue('input[name="receiveTxtReminder"]');
		// if we are here because of duplicate payment error, alter logic
		if($('input[name=IsTextButtonClicked]').val() == 'true'){
			$('input[name=selectedChannel]').val('TEXT_MESSAGE');
			$('input[name=textemailButton]:nth(1)').attr("checked","checked");
			bindPaymentButtonToSMS();			
		}
		else{
			$('input[name=selectedChannel]').val('EMAIL');
			$('input[name=textemailButton]:nth(0)').attr("checked","checked");
			bindPaymentButtonToEMAIL();			
		}
	}else if (isTextPaymentAllowedForAccount() && !isEmailPaymentAllowedForAccount()){
		paymentHeading = ' Phone';
		$('#mobile_number_box').fadeIn();
		$('#text_email_box').hide();
		$('#text_mobile_box').fadeIn();
		$('#promo_line_item').hide();
		$('input[name=selectedChannel]').val('TEXT_MESSAGE');
		$('input[name=textemailButton]:nth(1)').attr("checked","checked");
		//enable rentbytxt checkbox
		$('input[name="receiveTxtReminder"]').attr('checked',true);
		setCheckBoxValue('input[name="receiveTxtReminder"]');
		bindPaymentButtonToSMS();
	}else if (!isTextPaymentAllowedForAccount() && isEmailPaymentAllowedForAccount()){
		paymentHeading = ' Email';
		$('#mobile_number_box').fadeIn();
		$('#text_email_box').fadeIn();
		$('#text_mobile_box').hide();
		$('#promo_line_item').hide();
		$('input[name=selectedChannel]').val('EMAIL');
		$('input[name=textemailButton]:nth(0)').attr("checked","checked");
		//disable rentbytxt checkbox
		$('input[name="receiveTxtReminder"]').attr('checked',false);
		setCheckBoxValue('input[name="receiveTxtReminder"]');
		bindPaymentButtonToEMAIL();
	}
	else {
		$('#mobile_number_box').hide();
		$('input[name=selectedChannel]').val('ONLINE');
		$('input[name=textemailButton]').removeAttr('checked');
		$('#promo_line_item').show();
		//disable rentbytxt checkbox
		$('input[name="receiveTxtReminder"]').attr('checked',false);
		setCheckBoxValue('input[name="receiveTxtReminder"]');
		//bind payment button
		bindPaymentButtonOnline();
	}
	$('#emailorTextMessage').html(paymentHeading);	
}

//check if duplicate payment dialog is displayed. This completes the process of handling a duplicate payment, which is
//started on sections/confirmpayment_section.jsp. At this point, the correct handlers have already been bound to the 
//payment button (online, email, or text handlers), so no need to bind them again. see updateSupportedChannelsPaymentOptions
function checkIsFromDuplicatePayment(){
	if (duplicatePaymentAccountId != ''){
		// confirm payment dialog shows duplicates
		showConfirmPaymentDialog();
	}
	else if($('input[name=IsTextButtonClicked]').val() == 'true'){
		// user clicked on text me -- no duplicate payment found, so send text
		sendTextMessage();
		$('#textPaymentDialog').rpdialog('open');
	}
	else if($('input[name=IsEmailButtonClicked]').val() == 'true'){
		// user clicked on email me -- no duplicate payment found, so send email
		sendEmailMessage(false);
		$('#emailPaymentDialog').rpdialog('open');
		$('#emailPaymentDialog').find('#personEmail').text($('#emailAddress').val());
	}
}

/** ****************************************************************************************************** */
// Currency Calculation for Dollars($)
/** ****************************************************************************************************** */
//None of these alerts should happen!!

function checkCurrency(prevSymbol, symbol){
	if(prevSymbol != symbol){
		alert("Invalid Input Number!");
		return false;
	}
	return true;
}

function checkDollarCurrency(symbol){
	if("$" != symbol){
		alert("Invalid Input Number!");
		return false;
	}
	return true;
}

// Checks returns value ready to be parsed into Float
function checkValidCurrencyInput(input){
	input = $.trim(input);
	input = input.replace("$",'');
	input = input.replace(",",'');
	if(input.indexOf("-") != -1){
		alert("Input cannot have negative value!");
		return "invalid";
	}
	if(isNaN(input)){
		alert("Input is not a valid number!");
		return "invalid";
	}else{
		return parseFloat(input);
	}	
}

/** ****************************************************************************************************** */
// Promo Code
/** ****************************************************************************************************** */

$(function(){
	PromoCode.init({
		beforeSend: function() {
			// REMOVE-- No promo codes for TEXT_MESSAGE channel currently
			//TODO: Check we do want to remove in case of email ?
			if (isTextPaymentAllowedForAccount() || isEmailPaymentAllowedForAccount()) { 
				$('input[name="promoValue"]').val("");
				$('input[name="RedeemedValue"]').val("");
				$('input[name="PromotionCouponId"]').val("");
				changePromoVisibility();
				return false;
			}
			
			return {
				total: $('#amount_total').val(),
				serviceFee: $('input[name="serviceFeeAmount"]').val(),
				accountKey: $('input[name="selectedAccount"]').val(),
				selChannel: $('input[name="selectedChannel"]').val()
			};
			
		},
		success: function() {
			calculateTotal();
		},
		remove: function() {
			calculateTotal();
		}
	});
});

/** ****************************************************************************************************** */
// Mobile Number
/** ****************************************************************************************************** */
$(function(){
	
	// Register if user wants immediate text confirmation receipt
	$('input[name="sendTxtReceipt"]').change(function(){
		ga_event(getCurrentPage(), $(this).is(':checked') ? 'on' : 'off', $(this).attr('name'));
		setCheckBoxValue('input[name="sendTxtReceipt"]');
	});
	
	// Register if user wants a monthly text message reminder
	$('input[name="receiveTxtReminder"]').change(function(){
		ga_event(getCurrentPage(), $(this).is(':checked') ? 'on' : 'off', $(this).attr('name'));
		setCheckBoxValue('input[name="receiveTxtReminder"]');
		
	});
});

// handler for text/email radio button
$("input:radio[name=textemailButton]").change(function() {
	if ($(this).val() == 'EMAIL ME') {
		$('input[name=selectedChannel]').val('EMAIL');
		bindPaymentButtonToEMAIL();
	}
	else {
		$('input[name=selectedChannel]').val('TEXT_MESSAGE');
		bindPaymentButtonToSMS();		
	}
	// turn off validation for text/email if radio button is not selected
	disableTextOrEmailValidation();
	duplicatePaymentAccountId = '';
    calculateTotal();
});


function mobilePhoneBoxTxt() {
	setCheckBoxValue('input[name="sendTxtReceipt"]');
	setCheckBoxValue('input[name="receiveTxtReminder"]');
	$('#mobile_number_box').fadeIn('slow');
	$('#text_payment_heading').show();
	$('#text_receipt_heading').hide();
	$('#text_receipt_option').hide();
	if (hasAutoPayOrRentByText) {
		$('#text_reminder_option').hide();
	}
}
function mobilePhoneBoxReg() {
	if (hideTxtBox == "true") {
		$('#mobile_number_box').hide();	
		$('input[name="receiveTxtReminder"]').val("");
		$('input[name="sendTxtReceipt"]').val("");
	} else {
		setCheckBoxValue('input[name="sendTxtReceipt"]');
		setCheckBoxValue('input[name="receiveTxtReminder"]');
		$('#mobile_number_box').fadeIn('slow');	
		$('#text_payment_heading').hide();
		$('#text_receipt_heading').show();
		$('#text_receipt_option').show();
	}
}

function setCheckBoxValue(inputName) {
	var checked = $(inputName + ':checked').length;
	if(checked == 0){
		$(inputName).val("off");
	}else{
		$(inputName).val("on");
	}
}

/** ****************************************************************************************************** */
// Dialogs
/** ****************************************************************************************************** */
function bindPaymentButtonOnline() {
	// online payment
	$('#complete_payment_btn').text('CONTINUE').unbind('click').click(function(e){
		e.preventDefault();
		showConfirmPaymentDialog();
	});
	// end online payment
}

function bindPaymentButtonToSMS(){		
	$('#complete_payment_btn').text('TEXT ME').unbind('click').click(function(e){
		e.preventDefault();
		$('form').validationEngine('hideAll');
		if (!$('#paymentForm').validationEngine('validate')) {
			return false;
		}
		
		var mobile1 = $('#mobile1').val();
		var mobile2 = $('#mobile2').val();
		var mobile3 = $('#mobile3').val();
		$('#textPaymentDialog').find('#mobileNum').html('('+  mobile1 +') '+ mobile2 + "-" + mobile3);
		// check for duplicate payment -- message will be sent if handler comes back without a duplicate payment error
		checkTextOrEmailDuplicatePayment();		
	});
}

function bindPaymentButtonToEMAIL(){
	$('#complete_payment_btn').text('EMAIL ME').unbind('click').click(function(e){
		e.preventDefault();
		$('form').validationEngine('hideAll');
		if (!$('#paymentForm').validationEngine('validate')) {
			return false;
		}
		
		// check for duplicate payment -- message will be sent if handler comes back without a duplicate payment error
		checkTextOrEmailDuplicatePayment();		
	});
}

function checkTextOrEmailDuplicatePayment() {
	$('#paymentForm').submit();
}
// send a text payment
function sendTextMessage() {
	ga_event(getCurrentPage(), 'send_sms', 'sms');			
	$.fn.flash.status('Processing request ...').error('hide');
	$.ajax({
		url: requestUrl + 'textPaymentMsg',
		type: 'POST',
		data: $('#paymentForm').serialize(),
		error: function showError(xhr, status, error){
			ga_event(getCurrentPage(), 'send_sms', 'failed');
			$.fn.flash.status('hide').error("Oops.. " + xhr.responseText);
	 	},
		success: function(data){
			ga_event(getCurrentPage(), 'send_sms', 'success');
			//clickstream analytics -- trackingData is defined in oneclickpayment_001.jsp. re-use since userid and classid have already been set
			var trackingDataArray = [new analyticsTrackingData(getCurrentPage(), 'RENTBYTEXT_PAYMENT_INITIATED')];
			//track if user subscribed to rent by text
			if($('#text_reminder_option').is(':visible') && $('input[name=receiveTxtReminder]').val() == 'on'){
				trackingDataArray.push(new analyticsTrackingData(getCurrentPage(), 'RENTBYTEXT_PAYMENT_SETUP'));
				ga_event(getCurrentPage(), 'On', 'rent-by-text');
			}
			analyticsTracking.trackEventMulti(trackingDataArray);

			$.fn.flash.status('hide').notice(data.result);
		}
	});
};

//send an email payment
function sendEmailMessage(isResend) {
	ga_event(getCurrentPage(), 'send_email', 'email');
	$.fn.flash.status('Processing request ...').error('hide');
	$.ajax({
		url: requestUrl + (isResend ? 'reSendEmailPaymentMsg' : 'emailPaymentMsg'),
		type: 'POST',
		data: $('#paymentForm').serialize(),
		error: function showError(xhr, status, error){
			ga_event(getCurrentPage(), 'send_email', 'failed');
			$.fn.flash.status('hide').error("Oops.. " + xhr.responseText);
	 	},
		success: function(data){
			ga_event(getCurrentPage(), 'send_email', 'success');
			//clickstream analytics -- trackingData is defined in oneclickpayment_001.jsp. re-use since userid and classid have already been set
			analyticsTracking.trackEvent(getCurrentPage(), 'RENTBYEMAIL_PAYMENT_INITIATED');
			$.fn.flash.status('hide').notice(data.result);
		}
	});
};

function showConfirmPaymentDialog(){
	$('form').validationEngine('hideAll');
	if (!$('#paymentForm').validationEngine('validate')) {
		return false;
	}
	$('#confirm_renter_information #renter_name').html($('#firstname').val() + ' ' + $('#lastname').val());
	var unitAddress = $('#unitAddress').val();
	if ($.trim(unitAddress) != '') {
		$('#confirm_renter_information #renter_unit_address').html(unitAddress);
		$('#confirm_renter_information #unit_address').show();
	}
	else {
		$('#confirm_renter_information #unit_address').hide();
	}

	var $confirm_method = $('#confirm_payment_method .round_box');

	if($('input[name="serviceFeeType"]').val().toLowerCase() != "echeck"){
		$confirm_method.find('.confirm_echeck_account_info').hide();
		$confirm_method.find('#confirm_accImg').html($('#addCardLogo').html());
		$confirm_method.find('#confirm_accNum').html('ending in ' + $('#ccnum').val().slice(-4));		
	}
	else{
		$confirm_method.find('#confirm_accImg').html('<span class="echeck_logo"></span>');
		$confirm_method.find('#confirm_accNum').html('ending in ' + $('#accountNumber').val().slice(-4));		
		$confirm_method.find('#confirm_echeck_account_name').html(ucfirst($('#bankType').val()) + ' Account');
		$confirm_method.find('.confirm_echeck_account_info').show();
	}

	if ($('input[name="chooseProcess"]').val() == "DebitOrCredit") {
		$('#confirm_type').find('option[value="debit"]').attr("selected", "selected");
		$('input[name="processType"]').val("Debit Card/ATM");
		$confirm_method.find('#confirm_type').show();
	} else {
		$('input[name="processType"]').val("");
		$confirm_method.find('#confirm_type').hide();
	}
	if (checkCVV == "true" && $('input[name="serviceFeeType"]').val() != "echeck") {					
		$('#confirm_heading').text("Please enter your card's CVV code and confirm your payment.");
		$confirm_method.find('#confirm_cvv').show();
	} else {
		$confirm_method.find('#confirm_cvv').hide();
	}				
	
	var $confirm_summary = $('#confirm_payment_summary .round_box');
	var promoCodeVal = $('input[name="promoValue"]').val();
	$confirm_summary.find('#confirm_propAmount').text($('input[name="property_total"]').val());
	if ($('#serviceFeeAmount').val() != defaultAmount){
		$confirm_summary.find('#total_label').text('Vacation Rental Total');
		$confirm_summary.find('#confirm_service').show();
		$confirm_summary.find('#confirm_servAmount').text($('#serviceFeeAmount').val());
	} else {
		$confirm_summary.find('#total_label').text('Payment Total');
		$confirm_summary.find('#confirm_service').hide();						
	}
	$confirm_summary.find('#confirm_promoAmount').text(promoCodeVal);
	$confirm_summary.find('#confirm_totalAmount').text($('input[name="amount_total"]').val());
	$confirm_summary.find('#confirm_date').text($("#date").text());
	if(promoCodeVal){ 
		$confirm_summary.find('#confirm_promo').show();
	} else {
		$confirm_summary.find('#confirm_promo').hide();
	}
	ga_event(getCurrentPage(), 'open', 'confirmPaymentDialog');
	$('#confirmPayment').rpdialog('open', function(){
		$('#confirm_cvv2').addClass("field_focus").focus();
	});				
}

/** ****************************************************************************************************** */
// confirmation payment dialog
/** ****************************************************************************************************** */
function resetDialog() {
	duplicatePaymentAccountId = '';
	textOrEmailSelectedAccountId = '';
	$('input[name=IsTextButtonClicked]').val("false");
	$('input[name=IsEmailButtonClicked]').val("false");
	$('input[name=Force]').val("false");
	$('#duplicatePaymentList').hide();
	$('#completepayment').text('COMPLETE PAYMENT');
	calculateTotal();
	$.fn.flash.error('hide');
	$('form').validationEngine('hideAll');
}

$(function(){
	
	var $confirmPayment = $('#confirmPayment').rpdialog({
		'overlayOpacity'	: '0.6',
		'overlayColor'		:'#000',
		'borderColor'		: '#172f8c',
		'borderOpacity'		: '0.6',
		'borderWidth'		: '10px',
		'onclose'			: function() { resetDialog(); ga_event(getCurrentPage(), 'close', 'confirmPaymentDialog');  }
	});
	
	// hook the resend button
	$('#resend_message_btn').click(function(e){
		e.preventDefault();
		sendTextMessage();
	});
	// hook the resend email button
	$('#resend_email_btn').click(function(e){
		e.preventDefault();
		sendEmailMessage(true);
	});
	
	$('#payment_summary form input:visible, #payment_method select').each(function(){
		$(this).change(function(){
			
			$('form').validationEngine('hideAll');
			
		});
	});
		
	
	$('#gobackendedit').click(function(e){
		e.preventDefault();
		$confirmPayment.rpdialog('close');		
	});
	
	// button that shows up on confirm payment dialog -- see confirmpayment_section.jsp
	$('#completepayment').click(function(e){
		e.preventDefault();
		if ($('#paymentCvvForm').validationEngine('validate')) {
			// do action based on what user clicked
			if($('input[name=IsTextButtonClicked]').val() == 'true'){
				$confirmPayment.rpdialog('close');		
				sendTextMessage();
				$('#textPaymentDialog').rpdialog('open');
			}
			else if($('input[name=IsEmailButtonClicked]').val() == 'true'){
				$confirmPayment.rpdialog('close');		
				sendEmailMessage(false);
				$('#emailPaymentDialog').rpdialog('open');
				$('#emailPaymentDialog').find('#personEmail').text($('#emailAddress').val());
			}
			else{
				// submit form
				$('#complete_payment_btn').unbind('click').trigger('click');
			}
			// tracking
			ga_event(getCurrentPage(), 'continue', $('input[name=selectedChannel]').val());
		}
	});
	
	$('input[name=confirm_cvv2], input[name=text_confirm_cvv2]').change(function(e){
		e.preventDefault();
		$('input[name="cvv2"]').val($(this).val());
	});
	$('input[name="types"]').change(function(e){
		e.preventDefault();
		if($('#confirm_type').find('select option:selected').text() == "Debit Card"){
			$('input[name="processType"]').val("Debit Card/ATM");
		}else {
			$('input[name="processType"]').val("");
		}
	});
});
/** ****************************************************************************************************** */
// text payment dialog
/** ****************************************************************************************************** */
$(function(){
	$('#textPaymentDialog').rpdialog({
		'overlayOpacity'	: '0.6',
		'overlayColor'		:'#000',
		'borderColor'		: '#172f8c',
		'borderOpacity'		: '0.6',
		'borderWidth'		: '10px',
		'onclose'			: function() { resetDialog(); }
	});
	
	$('#editMobile').click(function(e){
		e.preventDefault();
		$('#textPaymentDialog').rpdialog('close');		
	});
});

/********************************************************************************************************* */
//email payment dialog
/********************************************************************************************************* */
$(function(){
	$('#emailPaymentDialog').rpdialog({
		'overlayOpacity'	: '0.6',
		'overlayColor'		:'#000',
		'borderColor'		: '#172f8c',
		'borderOpacity'		: '0.6',
		'borderWidth'		: '10px',
		'onclose'			: function() { resetDialog(); }
	});
	
	$('#editEmail').click(function(e){
		e.preventDefault();
		$('#emailPaymentDialog').rpdialog('close');
	});
});

/** ****************************************************************************************************** */
// help icons
/** ****************************************************************************************************** */
$(function(){
	
	$('#helpTextMessagePopup').rpdialog({
		'overlayOpacity'	: '0.6',
		'overlayColor'		:'#000',
		'borderColor'		: '#172f8c',
		'borderOpacity'		: '0.6',
		'borderWidth'		: '10px',
		'overflow'			: 'hidden'
	});

	$('#helpTextPayment').click(function(e){
		e.preventDefault();
		if ($('#account_type_tabs:visible').length == 0)
			$('#helpTextMessagePopup').rpdialog('open');
	});
	
	$('#helpTextMessagePopup button').click(function(e){
		e.preventDefault();
		$('#helpTextMessagePopup').rpdialog('close');
	});
	
	$('#helpCvv').hover(function(){
		if ($('#account_type_tabs:visible').length == 0) {
			var $this = $(this);
			var offset = $this.offset();
			$('#cvvTooltip').css({
				top: offset.top + $this.height() + 5,
				left: offset.left - ($this.width()*2),
				zIndex:9
			}).fadeIn();
		}
	}, function(){
		$('#cvvTooltip').fadeOut();
	}).click(function(e){
		e.preventDefault();
	});
	
	//show a welcome message only when logged in and not coming from EmailLink
	if (welcomeMessage != '' && welcomeMessage != '.' && $ ('input[name=IsEmailButtonClicked]').val() != 'true' && $ ('input[name=IsTextButtonClicked]').val() != 'true' && duplicatePaymentAccountId == '' && !$('#flash').is(':visible') && !$('#error .message').is(':visible')) {
		$(window).load(function(){
			$.fn.flash.notice(welcomeMessage);
		});
	}
});

// function to turn off validation for text/email if radio button is not selected
function disableTextOrEmailValidation(){
    var emailValidationClass = 'validate[required,custom[email]]';
    if($('input[name=textemailButton]:nth(0)').is(':checked')){ // email radio button
    	$('#emailAddress').removeClass(emailValidationClass).addClass(emailValidationClass);
    }
    else if($('input[name=textemailButton]:nth(1)').is(':checked')){ // text radio button
    	$('#emailAddress').removeClass(emailValidationClass);
    }
}

/* check if current account supports email channel */
function isEmailPaymentAllowedForAccount(){ return typeof(serviceFeesByChannel['EMAIL']) !== 'undefined';} 

/* check if current account supports text channel */
function isTextPaymentAllowedForAccount(){ return typeof(serviceFeesByChannel['TEXT_MESSAGE']) !== 'undefined'; } 

/* check if current account supports online channel */
function isOnlinePaymentAllowedForAccount(){ return typeof(serviceFeesByChannel['ONLINE']) !== 'undefined';} 

/* get service fees for current account and selected channel */
function getServiceFeesForAccount() { return serviceFeesByChannel[$('input[name=selectedChannel]').val()][$('input[name=serviceFeeType]').val()]; }

/* find out if text or email button was clicked */
function isTextOrEmailButtonClicked(){
	return $('input[name=IsTextButtonClicked]').val() == 'true' || $('input[name=IsEmailButtonClicked]').val() == 'true';
}