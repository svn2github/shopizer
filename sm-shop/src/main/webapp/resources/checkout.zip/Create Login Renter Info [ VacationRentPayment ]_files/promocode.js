/** ****************************************************************************************************** */
// Promo Code
/** ****************************************************************************************************** */
PromoCode = {
	options: {
		beforeSend: function() {},
		success: function() {},
		remove: function() {}
	},
	init: function(options) {
		PromoCode.options = $.extend(this.options, options);
		PromoCode.changePromoVisibility();	
		$('#apply_promo').click(function(){ 
			PromoCode.submitPromotionEntry(); 
		});
		$('#remove_promo').click(function(){ 
			PromoCode.removePromotionEntry(); 
		});
	},
	// Toggle what should be showing (Apply/Remove)
	changePromoVisibility: function(){
		if( $('input[name="promoValue"]').val() ){
			$('#apply_promo_div').hide();
			$('#remove_promo_div').show();
			$('#promo_code_div').hide();
			$('#promo_value_div').show();
		}else{
			$('#apply_promo_div').show();
			$('#remove_promo_div').hide();
			$('#promo_code_div').show();
			$('#promo_value_div').hide();
		}
	},
	// Clear values of promotion if user has removed them
	removePromotionEntry: function(){
		$('#promoCode').val(''); 
		$('input[name="promoValue"]').val("");
		$('input[name="RedeemedValue"]').val("");
		$('input[name="PromotionCouponId"]').val("");
		PromoCode.changePromoVisibility();
		PromoCode.options.remove();
	},
	// Find out if user's promo code is applicable
	submitPromotionEntry: function() {
		
		// Don't submit if there is no promo code entered
	    var promoCode = $('#promoCode').val();
	    if (promoCode == '' || promoCode == undefined) { return; }
	    
		var feesAndChannel = PromoCode.options.beforeSend();
		if (feesAndChannel === false)
			return;
		
		var total = feesAndChannel.total;
		var serviceFee = feesAndChannel.serviceFee;
		var accountKey = feesAndChannel.accountKey;
		var selChannel = feesAndChannel.selChannel;
	    
	    var regEx = /[^a-zA-Z 0-9]+/g;
	    total = total.replace(regEx,'');
	    serviceFee = serviceFee.replace(regEx,'');
	    
		$.ajax({
			url: '/promotion',
			type: 'POST',
			dataType: 'xml',
			cache: false,
			data: {'promotionCode':promoCode, 
				'total':total, 'convenienceFee':serviceFee, 
				'personKey':personKey, 'communityKey':communityKey,
				'channel':selChannel, 'accountKey':accountKey},
			error: function showError(xhr, status, error){
				$('#promoCode').validationEngine('showPrompt', 'Error submitting promo code', 'error', 'topRight', true);
		 	},
			success: function(xml) {
				if ($(xml).find("valid").text() == "true"){	
					var promoDisplayAmount = $(xml).find("displayCouponAmount").text();
					var couponAmount = $(xml).find("couponAmount").text();
					var promoId = $(xml).find("promotionCouponId").text();				
					
					$('input[name="promoValue"]').val("-" + promoDisplayAmount);
					$('input[name="RedeemedValue"]').val(couponAmount);
					$('input[name="PromotionCouponId"]').val(promoId);
					
					PromoCode.changePromoVisibility();
					PromoCode.options.success();
				} else {
					PromoCode.removePromotionEntry();
					$('#promoCode').validationEngine('showPrompt', 'Invalid promo code', 'error', 'topRight', true);
				}		   
			}
		 	
		});
		
	}
	
};
