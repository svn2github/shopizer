var accountTypeMap = {
	'debit' : 'Debit Card',
	'debitcard' : 'Debit Card',
	'mastercard' : 'MC',
	'visa' : 'VISA',
	'echeck' : 'eCheck',
	'debit_master' : 'MC Debit',
	'debit_visa' : 'VISA Debit',
	'discover' : 'Discover',
	'americanexpress' : 'AMEX',
	'star' : 'Star',
	'pulse' : 'Pulse',
	'nyce' : 'NYCE',
	'maestro' : 'Maestro'
};

$.fn.safeHtml = function(str) {
	$(this).html(String(str).replace(/&/g, '&amp;')
							.replace(/"/g, '&quot;')
                            .replace(/'/g, '&#39;')
                            .replace(/</g, '&lt;')
                            .replace(/>/g, '&gt;'));
}

function ucfirst(str) {
	return str.charAt(0).toUpperCase() + str.slice(1);
}

//return the ordinal number
function getOrdinal(n) {
   var s=["th","st","nd","rd"], v=n%100;
   return n+(s[(v-20)%10]||s[v]||s[0]);
}

function getMobileNumber(id) {
	var mobile = $('input[id^=' + id + ']');
	return $.trim(mobile[0].value + mobile[1].value + mobile[2].value);
}

function isMobileNumberValid(id) {
	var pattern = /\d{10}/;
	return pattern.test(getMobileNumber(id));
}

function getCurrentPage() {
	var gaCurrentPage = $('#gaCurrentPage').text();
	//there was no page name then we just use the url path
	if ($.trim(gaCurrentPage) == '')
		gaCurrentPage = 'Undefined: ' + location.pathname;
	return gaCurrentPage;
}

function ga_event(category, action, label) {
	//override page name to use custom google analytics page name
	if(gaPageName != undefined && gaPageName != ""){
		category = gaPageName;
	}
	var actionEvent = category + '-' + action;
	var labelEvent = actionEvent + '-' + label;
	_gaq.push(['_trackEvent', category, actionEvent, labelEvent]);
}

function getLastDayOfMonth(aDate){
	   // returns the last day of a given month
	    var m = new Number(aDate.getMonth());
	    var y = new Number(aDate.getYear());

	    var tmpDate = new Date(y, m, 28);
	    var checkMonth = tmpDate.getMonth();
	    var lastDay = 28;

	    while(lastDay <= 31){
	        temp = tmpDate.setDate(lastDay + 1);
	        if(checkMonth != tmpDate.getMonth())
	            break;
	        lastDay++;
	    }
	    return lastDay;
}

//check credit card expiration. It uses current day for comparison
function validateExpirationDate(field, rules, i, options) {
	var month = $('select[name="exp_month"]').val();
	var year = $('select[name="exp_year"]').val();
	if(month!= "" && year != ""){
		var today = new Date();
		var expDate = new Date(year, month-1, getLastDayOfMonth( new Date(year, month -1, 1) ));
		if(expDate < today) {
			return "* Credit card has expired.";
		}
		
	}else if(month == "" || year == "") {
		return "* Please select year and month";
	}
}

$(function(){
	
	//================================================================================================================================================
	// start framework js
	//================================================================================================================================================
	
	//freaking IE8&9 compatibility
	if (document.documentMode) {
		$('html').addClass('ie').addClass('ie'+document.documentMode);
		if (document.documentMode < 8)
			$('html').addClass('lte8');
	}
	
	$('form').validationEngine({
		validationEventTrigger: 'submit', 
		scroll: false,
		bubbleOpacity : 1
	});
	$('.flabel').inFieldLabels();
	$('input.amount').amount({triggerChange:true});
	
	$('form input.field').each(function(i, input){
		if ($(input).hasClass('submit')) {
			//last child enter key submits the form
			$(this).keypress(function(e){
				if (e.which == 13) {
					e.preventDefault();
					$(this).closest('form').submit();
					return false;
				}
			});
		}
		else {
			//moves to next sibling
			$(this).keypress(function(e){
				//catch enter key
				if (e.which == 13) {
					e.preventDefault();
					var n = 1;
					if (e.shiftKey)
						n *= -1;
					var inputs = $(this).closest('form').find(':input');
					inputs.eq( inputs.index(this) + n ).focus();
					return false;
				}
			});
		}
	});
	
	$('form').submit(function(){
		if ($(this).validationEngine('validate')) {
			$('button.button, button.sm_button, button.auto_button, input.sm_button	').each(function(index, button){
				$(button).addClass('grey').attr('disabled', 'disabled');
			});
			return true;
		}
		return false;
	});
	
	$('button.submit').click(function(){
		$(this).parents('form:first').submit();
	});
	
	//print button
	$('#printButton, .printButton').click(function(e){
		e.preventDefault();
//		ga_event(getCurrentPage(), 'print', 'receipt');
		window.print();
	});
	
	$(window).resize(function(e){
		$('form').validationEngine('updatePromptsPosition');
	});
	
	//interactive links with interactive styles
	$('a.interactive, input.interactive').click(function(e){
		var $this = $(this);
		if ($this.hasClass('disabled')) {
			e.preventDefault();
			return false;
		}
		
		$this.addClass('grey disabled');
	});
	
	$("a.interactive, input.interactive").ajaxComplete(function(event,request, settings){
		$(this).removeClass('grey disabled');
	});
	
	//================================================================================================================================================
	// preload images
	//================================================================================================================================================
	
	//================================================================================================================================================
	// start feedback
	//================================================================================================================================================
	
	//feedback dialog
	var $feedback_form = $('#feedback_form').rpdialog({
		'overlayOpacity'	: '0.6',
		'overlayColor'		:'#000',
		'borderColor'		: '#172f8c',
		'borderOpacity'		: '0.6',
		'borderWidth'		: '10px',
		'overflow'			: 'hidden',
		'onclose'			: function() { $('form').validationEngine('hideAll'); }
	});
	
	//feedback click
	$('#feedback').click(function(e){
		e.preventDefault();
		ga_event(getCurrentPage(), 'open', 'feedback_form');
		$feedback_form.rpdialog('open');
	});
	
	//feedback close
	$('#feedbackClose').click(function(e){
		e.preventDefault();
		$feedback_form.rpdialog('close');
	});
	
	$('#sendFeedback').click(function(e){
		e.preventDefault();
		ga_event(getCurrentPage(), 'submit', 'feedback_form');
		var $feedbackForm = $('#feedback_form form');
		$feedbackForm.validationEngine('attach');
		if ($feedbackForm.validationEngine('validate')) {
			$feedbackForm.validationEngine('detach');
			$(this).html('Processing ...').addClass('grey').attr('disabled', true);
			var $message = $('#feedback_form #message');
			$message.val($message.val() + '\r\n\r\nUser agent: ' + navigator.userAgent);
			$.ajax({
				url : $feedbackForm.attr('action'),
				type: 'PUT',
				data: $feedbackForm.serialize(),
				beforeSend: function() {
					$('#feedback_form form input, #feedback_form form textarea, #feedback_form form select').attr('disabled', true);
				},
				complete: function() {
					$('#feedback_form form input, #feedback_form form textarea, #feedback_form form select').attr('disabled', false);
					$('#feedback_form form #sendFeedback').html('SEND MY FEEDBACK').removeClass('grey').attr('disabled', false);
				},
				success: function(response) {
					
					$('#feedback_form .thankyou #response').html(response.message);
					
					$('#feedback_form .form').hide();
					$('#feedback_form .thankyou').fadeIn(function(){
						$('#feedback_form .thankyou #thankyouClose').click(function(e){
							e.preventDefault();
							var f = $feedback_form.data('feedbackTimeout');
							if (f != undefined || f > 0) {
								clearTimeout(f);
							}
							$feedback_form.data('feedbackTimeout', 0);
							$feedback_form.rpdialog('close', function(){
								$('#feedback_form .thankyou').hide();
								$('#feedback_form .form').show().find('form').each(function(){this.reset();});
							});
						});
					});
					var feedbackTimeout = setTimeout(function(){
						$('#feedback_form .thankyou #thankyouClose').click();
					}, 5000);
					$feedback_form.data('feedbackTimeout', feedbackTimeout);
				},
				error: function(response) {
					$('<div/>').dialog({
						modal: true, 
						width: 600,
						height: 400,
						title: "Ooops, we're sorry, but ...", 
						buttons : {
							OK : function() { $(this).dialog('close'); }
						} 
					}).html(response.responseText);
				}
			});
			
		}
		
	});
	
	
});

//remove zip code validation on credit card form
$(function(){ $('#cc_tab #zip').removeClass('validate[required,custom[onlyNumber],minSize[5],maxSize[5]]').addClass('validate[required]');});

//force firefox to re-execute javascript on page back/forward
function UnloadHandler() {}
$(function(){
	if(window.addEventListener){
		window.addEventListener('unload', UnloadHandler, false);
	}
	//re-enable all grayed out buttons
	$('button.button, button.sm_button, button.auto_button, input.sm_button	').each(function(index, button){
		$(button).removeAttr('disabled');
	});
});

//refactor code to bind events for a tooltip 
function bindTooltipHandlers(selector, helpMsg){
	//unit help popup
	$(selector).hover(function(){
		$(this).validationEngine('showPrompt', helpMsg, 'load', 'topRight', true);
	}, function() {
		var clicked = $(this).data('helpTooltip.clicked');
		if (!clicked) 
			$(this).validationEngine('hidePrompt');
	}).click(function(e){
		e.preventDefault();
		var clicked = $(this).data('helpTooltip.clicked');
		if (!clicked) 
			$(this).validationEngine('showPrompt', helpMsg, 'load', 'topRight', true);
		else
			$(this).validationEngine('hidePrompt');
		$(this).data('helpTooltip.clicked', !clicked);
	});	
}

/* --------------- functions for skinned dropdown ----------------------- */

/* style all select menus */
$(function(){ $('select').each(function(index, value){ styleSelectMenu( '#'+$(this).attr('id'), false ); }); });

/* hook onchange event refresh skinned dropdown when original dropdown changes */
$(function(){ $('select').bind('customOnChange.refresh', function(event, refreshFlag, refreshValue){ styleSelectMenu( '#'+$(this).attr('id'), true, refreshFlag, refreshValue);} ); }); 

function styleSelectMenu(cssSelector, isRefreshOnly, refreshFlag, refreshValue){
	if(isRefreshOnly === true){
		$('select' + cssSelector).selectmenu({ refreshFlag: refreshFlag, refreshValue: refreshValue });
	}
	else{
        $('select' + cssSelector).selectmenu({
				width: null, /* will use css width given to select */
				menuWidth: null, /* will be as long as the longest item, except for ie 7 (of course) */
				maxHeight: 300,
				refreshFlag: 'readDisableState',
				icons: [{find: '.echeck'},{find: '.visa'},{find: '.mastercard'},{find: '.americanexpress'},{find: '.discover'},{find: '.debit_visa'},{find: '.debit_master'},{find: '.debit'},{find: '.debitcard'},{find: '.star'},{find: '.pulse'},{find: '.nyce'} ], 
			    change: function(e, object){ $(this).selectmenu(); /* needed because for account dropdow, the underlying display name for cc or bank changes when a particular account is selected */ }
		});
	}
}

// validate skinned select menu
function validateSelectMenu(field, rules, i, options){
	// find id for select menu -- visible menu has id in the form "original_dropdown_id-menu", so get rid of -button part
	var selectMenuId = field.attr('id').substr(0, field.attr('id').indexOf("-"));
	if($('#' + selectMenuId).val() == ""){
		return "* This field is required.";
	}
}

/* --------------- end functions for skinned dropdown ----------------------- */

//Calculates service fee 
function calculateServiceFeeLocal(totalToProperty, flat, percent, minFee) {
	// whole numbers instead of decimals
	var amount = Math.round(totalToProperty * 100);			//convert to int 
	var newAmount = amount;
    
	newAmount = (newAmount * (10000 + percent)) / 10000;
	newAmount = Math.floor(newAmount); // turn double to int to truncate consistently with RPMath::calculateServiceFee
	newAmount = newAmount + flat;
	amount = newAmount - amount;
    
	if (amount < minFee)
		amount = minFee;

	return amount/100;
}




/* --------------- functions common to the 'add payment method' functionality ----------------------- */

function validateCardOrRoutingNumber(field, rules, i, options) {
	var isValid = field.data('valid');
	if (isValid === false) {
		return "Invalid number.";
	}
}

$(function(){		
	// Change billing address
	$('#updatebilling').click(function(e){
		e.preventDefault();
		if ($('#billing_address_form').validationEngine('validate')) {
			var billingAddress = $('input[name="street"]').val();
			if (billingAddress === undefined) {
				billingAddress = $('#street1').val();
				var street2 = $('#street2').val();
				if ($.trim(street2) !== '') {
					billingAddress += '<br/>' + street2;
				}
			}
			var billingZip = $('input[name="zip"]').val();
			var billingCity = $('input[name="city"]').val();
			var billingState = $('#state option:selected').val();
			var formattedAddress = billingAddress + '<br/>' + billingCity + ', ' + billingState + ' ' + billingZip;
			var country = $('#country').val();
			if ($.trim(country) !== '')
				formattedAddress += '<br/>' + country;
			$('#formattedBilling').html(formattedAddress);		
			$('#billing_address #billing_form').slideToggle();
			$('#billing_summary').slideToggle();
		}
	});		
	// quickpayment update billing address
	$('#billing_address #editbilling').click(function(e){
		e.preventDefault();
		$('form').validationEngine('hideAll');
		$('#billing_summary').slideToggle();
		$('#billing_address #billing_form').slideToggle();
	});
	//show card logo
	$('#ccnum, #routingNumber').keydown(function(e){
		var code = (e.keyCode ? e.keyCode : e.which);
		var functional = false;

		// allow key numbers, 0 to 9
		if((code >= 48 && code <= 57) || (code >= 96 && code <= 105)) {
			functional = true;
		}

		// check Backspace, Tab, Enter, Delete, and left/right arrows
		if (code ==  8) functional = true;
		if (code ==  9) functional = true;
		if (code == 13) functional = true;
		if (code == 46) functional = true;
		if (code == 37) functional = true;
		if (code == 39) functional = true;
		
		if (e.altKey || e.ctrlKey || e.shiftKey || e.metaKey) functional = true;

		if (!functional) {
			e.preventDefault();
			e.stopPropagation();
		}
	}).keyup(function(e){
		var number = $(this).val() || '';
		if (number.length >= ($(this).attr('id') == 'ccnum' ? 16 : 9)) {
			var code = (e.keyCode ? e.keyCode : e.which);
			if((code >= 48 && code <= 57) || (code >= 96 && code <= 105)) {
				$(this).change();
			}
		}
	}).change(function(e){
		//store the old value so we don't fire the ajax twice (change and paste)
		var $this = $(this);
		var oldValue = $('#addCardLogo').data('oldValue');
		var number = $.trim($this.val()) || '';
		if (number != '' && number != oldValue) {
			$this.removeClass('error');
			$('#addCardLogo').data('oldValue', number);
			var type = $this.attr('id') == 'ccnum' ? 'type' : 'routing';
			var url = requestUrl + type + '/' + number;
			url += (typeof(jsid) === 'undefined' ? '' : (';jsessionid=' + jsid));
			$.ajax({
				url: url,
				type: 'GET',
				success: function(data){
					$this.validationEngine('hide');
					if (type == 'type') {
						$('#addCardLogo').hide().html('<span class="' + data.type.toLowerCase() + '_logo"></span>').fadeIn('slow');
						//catch any error as this function is optional
						try {updateServiceFee(data);}catch(e){}
					}
					$this.data('valid', true);
				}, 
				error: function(response) {
					$this.data('valid', false);
					//we can't use $this.validationEngine('validate') as it doesn't work! 
					$this.validationEngine('showPrompt', validateCardOrRoutingNumber($this), 'error', 'topRight', true);
					$this.addClass('error');
					$('#addCardLogo').hide();
				}
			});
		}
	}).on('paste', function(e) {
		var $this = $(this);
		setTimeout(function(){$this.change();}, 0);
	}).data('valid', false);
});

function getNewBankData(isChecking, personKey, mobilePermits, mobileKey){
	var nameOnAccount = $('input[name="nameOnAccount"]').val();
	var routingNumber = $('input[name="routingNumber"]').val();
	var accountNumber = $('input[name="accountNumber"]').val();	
	
	return newBankData = {'isChecking':isChecking, 'nameOnAccount':nameOnAccount, 
			'routingNumber':routingNumber, 'accountNumber':accountNumber,
			'personKey':personKey, 'mobilePermittedTypes': mobilePermits, 'mobileKey':mobileKey};
}

function getNewCCData(accountChannel, mobilePermits, mobileKey){
	var cardNumber = $('input[name="ccnum"]').val();
	var expirationMonth = $('#exp_month_panel').find('select option:selected').text();
	var expirationYear = $('#exp_year_panel').find('select option:selected').text();
	var firstNameOnCard = $('input[name="firstNameOnCard"]').val();
	var lastNameOnCard = $('input[name="lastNameOnCard"]').val();
	var billingAddress = $('input[name="street"]').val();
	var billingZip = $('input[name="zip"]').val();
	var billingCity = $('input[name="city"]').val();
	var billingState = $('#state option:selected').val();

	return newCCData = {'cardNumber':cardNumber, 'expirationMonth':expirationMonth, 
			'expirationYear':expirationYear, 'firstNameOnCard':firstNameOnCard, 
			'lastNameOnCard':lastNameOnCard,'billingAddress':billingAddress, 
			'billingZip':billingZip,'billingCity':billingCity, 
			'billingState':billingState, 'channel':accountChannel,
			'permittedTypes':permits, 'personKey':personKey, 
			'mobilePermittedTypes': mobilePermits, 'mobileKey':mobileKey};
}

function isNewBankDataEmpty() {
	var data = getNewBankData();
	return $.trim(data.nameOnAccount) == '' && $.trim(data.routingNumber) == '' && $.trim(data.accountNumber) == '';
}

function isNewCCDataEmpty() {
	var data = getNewCCData();
	return $.trim(data.cardNumber) == '' && $.trim(data.expirationMonth) == 'Month' && $.trim(data.expirationYear) == 'Year'
		&& $.trim(data.firstNameOnCard) == '' && $.trim(data.lastNameOnCard) == '';
}

//show billing address form if any field is empty and hide the read-only text
function showBillingAddressFormIfEmpty(isCCTab){
	$('form').validationEngine('hideAll');
	if (isCCTab && ( (!$('#billing_form').is(':visible') && $('#billing_form input:text[value=""]').length > 0) || $('#formattedBilling').text() == 'Not Provided') ) {
		$('#billing_summary').hide();
		$('#billing_address #billing_form').show();
	}	
}

//Restrict account types that may be added
function setAllowedAddPaymentTypes(tabsId, ccTabIndex, eCheckTabIndex, ignoreRestrictions, noCCPermitted, noBankPermitted, populateCCTabs, defaultAddPaymentMethodToACH){
	if(ignoreRestrictions == false){
		$('#cclogos').html(populateCCTabs);
		//check if neither method is enabled
		if (noCCPermitted && noBankPermitted){
			$.fn.flash.error('Payments are not currently accepted for your profile. Please contact your manager for further information.');
			//$('#account_tabs').tabs('disable'); // does not work. do it differently below
			$(tabsId).tabs("remove", 1); // hide cc tab		
			$(tabsId + ' input').addClass('grey').attr('disabled', 'disabled'); //disable all fields
			$(tabsId + ' button').addClass('grey').attr('disabled', 'disabled'); //disable all fields
		}
		else if (noCCPermitted)
			$(tabsId).tabs("remove", ccTabIndex); // hide cc tab		
		else if (noBankPermitted) 
			$(tabsId).tabs("remove", eCheckTabIndex); // hide bank tab	
	}
	
	// select tab -- check to make sure tabs have not beed removed based on permissions
	if($(tabsId).tabs('length') > 1){
		// check property preference that defaults payment type to ach
		if(defaultAddPaymentMethodToACH == 'true')
			$(tabsId).tabs('select', eCheckTabIndex);
		else
			$(tabsId).tabs('select', ccTabIndex);
	}
}

/* ------------- end of functions common to the 'add payment method' functionality ------------------ */


/* -------------------- account select dropdown ------------------------- */
function setupAccountSelectMenu(selectMenuId, serviceFeeId){
	var selectMenuIdSelector = '#' + selectMenuId;
	var serviceFeeIdSelector = typeof(serviceFeeId) !== 'undefined' && serviceFeeId != "" ? "#"+ serviceFeeId : undefined ;
	
	// update selected option if it's echeck so it displays the short name
	updateAccountsDisplayName(selectMenuIdSelector);

	// refresh skinned year dropdown, since it gets dynamically by updateAccountsDisplayName()
	$(selectMenuIdSelector).trigger('customOnChange.refresh');
	
	// set read-only service fee
	if(typeof(serviceFeeIdSelector) !== 'undefined')
		updateServiceFeeMsg(selectMenuIdSelector, serviceFeeIdSelector);

	$(selectMenuIdSelector).change(function(){
		// update selected option if it's echeck so it displays the short name
		updateAccountsDisplayName(selectMenuIdSelector);		
		
		// update service fee displayed
		if(typeof(serviceFeeIdSelector) !== 'undefined')
			updateServiceFeeMsg(selectMenuIdSelector, serviceFeeIdSelector);
	});	
}

//update/refresh the display names for the accounts on the dropdown
function updateAccountsDisplayName(selectMenuIdSelector){
	// restore long display on bank accounts in dropdown
	$(selectMenuIdSelector + " option").each(function(index, element){
		$(element).html(getAccountDisplay($(element)));
	});

	// update selected option if it's echeck so it displays the short name
	var selectedOption = $(selectMenuIdSelector + " option:selected");
	if(getAccountType(selectedOption) == 'echeck'){
		selectedOption.html(getAccountShortDisplay(selectedOption));
	}
}

//update the service fee msg for the selected account
function updateServiceFeeMsg(selectMenuIdSelector, serviceFeeIdSelector){
	// service fee
	var fee = getServiceFeeDisplayMsg($(selectMenuIdSelector + " option:selected"));
	if (fee == '$0.00'){
		$(serviceFeeIdSelector).hide();
	}
	else {
		$(serviceFeeIdSelector + ' b').text(fee);
		$(serviceFeeIdSelector).fadeIn();			
	}
}

//get service fee display for option -- stored in the option's title field
function getServiceFeeDisplayMsg(option){
	var titleArray = option.attr("title").split("|");
	return $.trim(titleArray[0]);
}

//get short display for option -- stored in the option's title field
function getAccountShortDisplay(option){
	var titleArray = option.attr("title").split("|");
	return $.trim(titleArray[1]);
}

//get display for option -- stored in the option's title field
function getAccountDisplay(option){
	var titleArray = option.attr("title").split("|");
	return $.trim(titleArray[2]);
}

//get account type for option -- stored in the option's title field
function getAccountType(option){
	var titleArray = option.attr("title").split("|");
	return $.trim(titleArray[3]);
}

//get individual service fees for option -- stored in the option's title field
function getServiceFees(option){
	var titleArray = option.attr("title").split("|");
	var feeObj = { flatFee: titleArray[4], rate: titleArray[5], minFee: titleArray[6]};	
	return feeObj;
}
/* -------------------- end account select dropdown ------------------------- */


/* -------------------- mobile banner ------------------------- */
$(function(){
	if(typeof(showMobileSiteBanner) != 'undefined' && showMobileSiteBanner.toLowerCase() == 'true' && getCurrentPage() == 'login'){
		handleMobileBanner();
	}
});

//display mobile site banner if user is on a mobile device
function handleMobileBanner(){
		// first, check if this is a mobile browser -- don't show for iphone5 since mobile site is not ready to handle the iphone5
		if($.browser.mobile){
			// now check if the mobile browser supports position:fixed, which allows us to anchor the banner to bottom of page
		    if( !fixedToolbarSupportBlacklist() ){			
				// anchor banner -- will be shown after interval function executes first time
				// set interval to re-adjust/resize logo and text based on screen resulution/orientation
				setInterval(checkBannerHeight,500);
			}
			else{
				// just show banner under login form
				$('#mobile_banner_container_mid').show();
			}
		}
}

var oldBannerHeight = 0;
//check if mobile banner logo and text need to be re-adjusted/resized based on screen resulution/orientation
function checkBannerHeight(){
	var bannerDiv = $('#mobile_banner_container_footer .mobile_banner');		
	var newBannerHeight = bannerDiv.height();

	if(newBannerHeight != oldBannerHeight){
		var mobileLogoContainer = $('#mobile_banner_container_footer .mobile_logo');
		var mobileLogoImg = $('#mobile_banner_container_footer .mobile_logo img');
		var mobileButtonContainer = $('#mobile_banner_container_footer .mobile_btn');
		var mobileButtonText = $('#mobile_banner_container_footer .mobile_btn span');
	
		// hide banner if user zooms in to specific level
		if(bannerDiv.width() <= 375)
			bannerDiv.css('visibility', 'hidden');
		else
			bannerDiv.css('visibility', 'visible');

		// resize text and image if the banner is greater than a specific height				
		var scaleFactor = mobileLogoImg.width() / mobileLogoImg.height();
		mobileLogoImg.css('height',bannerDiv.height()-(bannerDiv.height() * .5)).css('width', mobileLogoImg.height()*scaleFactor);
		// re-adjust margin to vertically-center image and button text -- top offset is 50%
		mobileLogoContainer.css('margin-top', -1 * mobileLogoContainer.height()/2);			
		mobileButtonText.css('margin-top', -1 * mobileButtonText.height()/2);						

		// hide logo if left button edge is overlapping with right edge of logo
		if(mobileLogoContainer.position().left + mobileLogoImg.width() >= mobileButtonContainer.position().left + 5)
			mobileLogoContainer.css('visibility', 'hidden');
		else		
			mobileLogoContainer.css('visibility', 'visible');
			
		oldBannerHeight = newBannerHeight;

		// show main container if this is the first time
		if($('#mobile_banner_container_footer').css("display") == 'none'){
			$('#mobile_banner_container_footer').show('slow');
		}
	}
}		

//Browser detection! Weeee, here we go...
//Unfortunately, position:fixed is costly, not to mention probably impossible, to feature-detect accurately.
//Some tests exist, but they currently return false results in critical devices and browsers, which could lead to a broken experience.
//Testing fixed positioning is also pretty obtrusive to page load, requiring injected elements and scrolling the window
//The following function serves to rule out some popular browsers with known fixed-positioning issues
//This is a plugin option like any other, so feel free to improve or overwrite it
function fixedToolbarSupportBlacklist() {
	var w = window,
		ua = navigator.userAgent,
		platform = navigator.platform,
		// Rendering engine is Webkit, and capture major version
		wkmatch = ua.match( /AppleWebKit\/([0-9]+)/ ),
		wkversion = !!wkmatch && wkmatch[ 1 ],
		ffmatch = ua.match( /Fennec\/([0-9]+)/ ),
		ffversion = !!ffmatch && ffmatch[ 1 ],
		operammobilematch = ua.match( /Opera Mobi\/([0-9]+)/ ),
		omversion = !!operammobilematch && operammobilematch[ 1 ];

	if(
		// iOS 4.3 and older : Platform is iPhone/Pad/Touch and Webkit version is less than 534 (ios5)
		( ( platform.indexOf( "iPhone" ) > -1 || platform.indexOf( "iPad" ) > -1  || platform.indexOf( "iPod" ) > -1 ) && wkversion && wkversion < 534 ) ||
		// Opera Mini
		( w.operamini && ({}).toString.call( w.operamini ) === "[object OperaMini]" ) ||
		( operammobilematch && omversion < 7458 )	||
		//Android lte 2.1: Platform is Android and Webkit version is less than 533 (Android 2.2)
		( ua.indexOf( "Android" ) > -1 && wkversion && wkversion < 533 ) ||
		// Firefox Mobile before 6.0 -
		( ffversion && ffversion < 6 ) ||
		// WebOS less than 3
		( "palmGetResource" in window && wkversion && wkversion < 534 )	||
		// MeeGo
		( ua.indexOf( "MeeGo" ) > -1 && ua.indexOf( "NokiaBrowser/8.5.0" ) > -1 ) ) {
		return true;
	}

	return false;
}

// check for iphone 5 using screen height check
function isIPhone5(){
	return (navigator.platform.indexOf( "iPhone" ) > -1 && window.screen.height==568 );
}

/* -------------------- end mobile banner ------------------------- */

/* persist username on login */
function readPersistedField(name, fieldId){
	var cookieValue = readCookie(name);

	if(cookieValue != null && cookieValue != "" && cookieValue != "-1"){ 
		$('#'+fieldId).val(stripUserNameChars(cookieValue)).change(); 
	}
}

function stripUserNameChars(str){
	return str.replace(/["<>]/g,'');
}

function createCookie(name,value,days) {
	var expires = "";
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days * 24 * 60 * 60 * 1000));
		expires = "; expires="+date.toGMTString();
	}
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name,"",-1);
}
